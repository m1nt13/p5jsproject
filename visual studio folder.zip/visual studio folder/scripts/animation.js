
var x;
var y;
var changeDirection;

function setup(){
    createCanvas(windowWidth,windowHeight);

    

    frameRate(40);

    xPos = 0;
    yPos = 0;
    y = 20;
    changeDirection = false;
    //act as switch for having rectangles go up and down

}

function draw(){

    background('#e1cce3');

 
    

    fill ("#7544ad");

 

    // INCREMENT X POSITION BY 5 EVERY DRAW LOOP
    rect(xPos, y, 100, 200);
    xPos += 5;

    

    if(y>height/32){
		changeDirection=true}


	else if (y<=0){
		changeDirection=false}


	
	if (y>=0 && changeDirection == false){
		y=y+1}


	else if(changeDirection == true){
		y=y-1}

    
    // Decrement Y Position by 5 Every draw loop
    rect (100, yPos, 100, 200);
    yPos -= 5;


}

// function draw(){

//     let randomX = random(width); 

//     // let randomY = random(height);
//     let y = parabola(randomX);

//     let randomSize = random(15, 100); 

 
//     r = random(100, 200); // r is a random number between 0 - 255
//     g = random(10, 100); // g is a random number betwen 100 - 200
//     b = random(200, 120); // b is a random number between 0 - 100
//     a = random(200,255); // a is a random number between 200 - 255
    
//     noStroke();
//     fill(r, g, b, a);
//     circle( randomX, y, randomSize); 

// }

// function parabola(randomX){
//     h = (windowWidth/2);
//     let square = (randomX-h) * (randomX-h);
//     return ((square/400))+100;


// }



