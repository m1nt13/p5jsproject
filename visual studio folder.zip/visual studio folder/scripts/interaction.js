//interaction
// let grayValue = 0;

// let posX, posY

let greenVal = 255;
function setup(){
    createCanvas(800,600);
    
    // posX = 100;
    // posY = 75;
}

function draw(){

    // background('blue');

    //mouseX and mouseY
    // ellipse(mouseX, mouseY, 100, 100);

    //mousepressed

//     if(mouseIsPressed){
//         ellipse(mouseX, mouseY, 180, 180);
//     }

// background('grayValue');

//Distance
//caclulate distance between point at (10, 50) and another at (mouseX,mouseY)
//let distance = dist(10, 50, mouseX, mouseY);

//key vairable
//stores value of most recently pressed key

if (key === 'a'){
    fill ('red');
} else {
    fill ('green');
}

ellipse(width /2, height / 2, 100, 100)

//keyCode
//detect special keyu such as BACKSPACE, RETURN, RIGHT_ARROR...
//keyCode deals with ASCII
//if

background(255);
fill(255, 0 , 255)

//check if keyCode or spacebar is pressed ==> keyCode '32'
// if (keyCode === 32) {
//     ellipse(width / 2, height / 2, 100, 100);
// }

//Key events
//keyPressed(), keyReleased(), keyTyped(), keyisDown()

// rect (posX, posY, 100, 75);
// square(posX, posY, size);

//ellipse with colorValue
fill (120, greenVal, 100);
ellipse(width / 2, height/ 2, 200, 200);


}

// function keyReleased(){
//     if (key === m ){
//         posX = random(400);
//         posY = random(400);
//         size = randome(200;)
//     }

    
// //keyTyped
// funtion keyTyped(){
//     posX = random(width);
//     posY = random(height);

// }
// }



// function mousePressed(){
//     greyValue = random(255);
// }

//keyPressed
function keyPressed(){ 
    if(greenVal >= 0 ){
    greenVal -= 10;
} else{
    greenVal = 255;
}

}
