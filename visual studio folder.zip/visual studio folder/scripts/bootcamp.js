function setup(){
    //Create a canvas with an 800px width, and 600px height
    //create Canvas(width,height)
    createCanvas(800, 600);

    //DEFAULT CANVAS is 100x100 px

    background(127);

    //Setup() function runs once, contains code that defines initial state of the sketch. Such as: bg color, canvas size, inital values and global variables
    // width and height
    // console.log(width);
    // console.log(height);
}

function draw(){
    //loop infinitely after setup() is run
    // point(400,500);
    // line(10, 20, 30, 40);
    // rect (10,30, 100, 50);
    // square (100, 200, 70);
    // ellipse (10, 20, 25, 55);
    // circle (70, 90, 400);
    // triangle (5, 10, 15, 20, 25, 40);
    // quad (40, 30, 25, 60, 80, 30, 25, 80);

    
    background(200,200,250);

    //creates diagonal lines with thick strokes
    stroke(150,100,200);

    strokeWeight(5);
    line (0,5,700,600);
    
    strokeWeight(5);
    line (0, 5, 500, 750);

    //all circles made without outlines
    noStroke();
    
    fill(100, 100, 200);
    circle(100,100,150);

    fill(200,150,250);
    circle(750,500,500);
    
    fill(100, 25, 105);
    circle(500, 100, 105);

    fill(100, 200, 205);
    circle(100, 300, 105);

    fill(350,150,250);
    circle(200,500,250);
}
