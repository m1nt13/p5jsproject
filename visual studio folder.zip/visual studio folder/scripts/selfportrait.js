function setup(){
createCanvas(windowWidth,windowHeight);
}

function draw(){

    //shirt
    fill(190, 100, 75);
    ellipse(windowWidth / 2, 900, 500, 600);

    //neck
    fill (190,160,120);

    ellipse(windowWidth / 2, 590, 125, 300);

    //head
    ellipse(windowWidth / 2, windowHeight / 2, 275, 350);

    //face parts

    //eyelashes
    fill(0,0,0);
    ellipse(660,340,60,30);

    //make ellipse to make a crescent
    fill(190,160,120);
    noStroke();
    ellipse(660,345,60,20);

    fill(0,0,0);
    ellipse(770,340,60,30);
    
    fill(190,160,120);
    noStroke();
    ellipse(770,345,60,20);

     //bottomlash(left)
     fill(0,0,0);
     triangle(650,370,640,380,652,360);

     //bottomlash(right)
     fill(0,0,0);
     triangle(850,370,840,380,852,360);

  

    //eyes
    fill(0,0,0);
    ellipse(660, 350, 30, 50);
    ellipse(770, 350, 30, 50);

    //mouth

   fill(200,10,40);
   ellipse(windowWidth / 2, 470, 120, 30);
   
   fill(190,160,120);
   ellipse(windowWidth / 2, 465, 120, 30);


   



}