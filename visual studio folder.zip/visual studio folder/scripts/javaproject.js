console.log('running javaproject.js');

//name global variables
let clover;
let floor;
let ob;
let dirt;
let grass;
let dirtImg;
let grassImg;
let bgImg;
let bg;
let goal;

function preload(){
  //make the sprite for the player
  clover = new Sprite (50,50,100,100);
  clover.spriteSheet = 'assets/clover_sprite_sheet_beta.png';
  clover.anis.offset.x = 2;
  clover.anis.frameDelay = 8;
  
  //add animations
  clover.addAnis ({		run: { row: 0, frames: 8 },
		jump: { row: 1, frames: 6 },
		stand: { row: 3, frames: 1 }
	});
 clover.ani = 'run';

 //set up dirt and grass tiles
  dirtImg = loadImage("assets/dirt_tile.png");

}

function setup() {
   createCanvas(800,  600);
   //load dirt
   dirt= new Sprite(dirtImg, 0, 0);
 
   
  createCanvas(windowWidth, windowHeight);
world.gravity.y = 10;



}

function draw() {


  //goal set
  

  //visuals for the clover sprite


  //controls
  //ground set up
  if (camera.x > dirt.x + width / 2) {
    dirt.x += width;
  }

  
   //controls
   if (kb.pressing('left')) {
    clover.ani = 'run'
    clover.vel.x = -5
    clover.mirror.x = true;}

  else if (kb.pressing('right')) {
    clover.ani = 'run'
    clover.vel.x = 5
    clover.mirror.x = false;}

  else clover.vel.x = 0;
  
  
  if (kb.presses('up')) { 
    clover.vel.y = -5
  }

  if (kb.pressing('up'))clover.ani = 'jump';

  if (clover.ani.name == 'run' && abs(clover.vel.x) < 0.1) {
		clover.ani = 'stand';
	}
    

 

//debug sprites/shows hitboxes(?)
	allSprites.debug = mouse.pressing();


  

}

//victory text after goal
function victory() {
textsize(100);
text('You win!', 400,400);
}


