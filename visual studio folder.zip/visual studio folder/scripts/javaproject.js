console.log('running javaproject.js');

//name global variables
let clover;
let floor;
let ob;
let dirt;
let grass;
let dirtImg;
let grassImg;
let bgImg;
let bg;
let goal;

function preload(){
  //make the sprite for the player
  clover = new Sprite (50,50,100,100);
  clover.spriteSheet = 'assets/clover_sprite_sheet_beta.png';
  clover.anis.offset.x = 2;
  clover.anis.frameDelay = 8;
  
  //add animations
  clover.addAnis ({		run: { row: 0, frames: 8 },
		jump: { row: 1, frames: 6 },
		stand: { row: 3, frames: 1 }
	});
 clover.ani = 'run';

 //set up dirt and grass tiles
  dirtImg = loadImage("assets/dirt_tile.png");

}

function setup() {
   createCanvas(800,  600);
   //load dirt
   dirt= new Sprite(dirtImg, 0, 0);
 
   
  createCanvas(windowWidth, windowHeight);
world.gravity.y = 10;



}

function draw() {


  //goal set
  

  //visuals for the clover sprite


  //controls
  //ground set up
  if (camera.x > dirt.x + width / 2) {
    dirt.x += width;
  }

  
  
    

 

//debug sprites/shows hitboxes(?)
	allSprites.debug = mouse.pressing();


  

}

//victory text after goal
function victory() {
textsize(100);
text('You win!', 400,400);
}


